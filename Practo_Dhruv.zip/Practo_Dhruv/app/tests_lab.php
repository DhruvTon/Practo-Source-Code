<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tests_lab extends Model
{
    //
    public $timestamps = false;
}
